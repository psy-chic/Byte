import ByteLogo from "@/components/ByteLogo";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import ThemeToggle from "@/components/ThemeToggle";
import { TrendingUp, Newspaper, Calendar, Search, ArrowRight } from "lucide-react";

export default function Landing() {
  const handleLogin = () => {
    window.location.href = "/api/login";
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b border-border">
        <div className="max-w-7xl mx-auto px-4 md:px-8">
          <div className="flex items-center justify-between gap-4 h-16">
            <ByteLogo size="md" />
            <div className="flex items-center gap-2">
              <ThemeToggle />
              <Button onClick={handleLogin} data-testid="button-login-header">
                Sign In
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main>
        <section className="py-16 md:py-24">
          <div className="max-w-7xl mx-auto px-4 md:px-8 text-center">
            <h1 className="font-serif text-4xl md:text-6xl font-bold mb-6" data-testid="text-hero-title">
              Your Gateway to{" "}
              <span className="text-primary">Financial Intelligence</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto mb-8">
              Aggregating news from global financial portals. Stay informed on stocks, economy, and markets with personalized recommendations.
            </p>
            <div className="flex flex-wrap items-center justify-center gap-4">
              <Button size="lg" onClick={handleLogin} data-testid="button-get-started">
                Get Started
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
              <Button size="lg" variant="outline" onClick={handleLogin} data-testid="button-learn-more">
                Learn More
              </Button>
            </div>
          </div>
        </section>

        <section className="py-16 bg-card">
          <div className="max-w-7xl mx-auto px-4 md:px-8">
            <h2 className="font-serif text-2xl md:text-3xl font-bold text-center mb-12">
              Everything You Need for Financial News
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card>
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 rounded-md bg-chart-1/10 flex items-center justify-center mx-auto mb-4">
                    <Newspaper className="h-6 w-6 text-chart-1" />
                  </div>
                  <h3 className="font-semibold mb-2">Curated News</h3>
                  <p className="text-sm text-muted-foreground">
                    Articles from TOI, Mint, Business Times, and more global sources
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 rounded-md bg-chart-2/10 flex items-center justify-center mx-auto mb-4">
                    <TrendingUp className="h-6 w-6 text-chart-2" />
                  </div>
                  <h3 className="font-semibold mb-2">Stock Insights</h3>
                  <p className="text-sm text-muted-foreground">
                    NSE stock news with TradingView charts integration
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 rounded-md bg-chart-3/10 flex items-center justify-center mx-auto mb-4">
                    <Calendar className="h-6 w-6 text-chart-3" />
                  </div>
                  <h3 className="font-semibold mb-2">Financial Calendar</h3>
                  <p className="text-sm text-muted-foreground">
                    Track earnings, dividends, IPOs, and policy meetings
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 rounded-md bg-chart-4/10 flex items-center justify-center mx-auto mb-4">
                    <Search className="h-6 w-6 text-chart-4" />
                  </div>
                  <h3 className="font-semibold mb-2">Smart Search</h3>
                  <p className="text-sm text-muted-foreground">
                    Find articles by keyword, company, or topic instantly
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        <section className="py-16">
          <div className="max-w-7xl mx-auto px-4 md:px-8 text-center">
            <h2 className="font-serif text-2xl md:text-3xl font-bold mb-4">
              Ready to Stay Informed?
            </h2>
            <p className="text-muted-foreground mb-8">
              Join thousands of investors and professionals who trust Byte for their financial news.
            </p>
            <Button size="lg" onClick={handleLogin} data-testid="button-cta-signin">
              Sign In Now
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </section>
      </main>

      <footer className="border-t border-border py-8">
        <div className="max-w-7xl mx-auto px-4 md:px-8 text-center text-sm text-muted-foreground">
          <ByteLogo size="sm" />
          <p className="mt-4">Financial news aggregation platform</p>
        </div>
      </footer>
    </div>
  );
}
