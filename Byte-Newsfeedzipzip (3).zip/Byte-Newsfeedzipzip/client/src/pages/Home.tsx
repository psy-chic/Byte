import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Header from "@/components/Header";
import FilterBar from "@/components/FilterBar";
import NewsFeed from "@/components/NewsFeed";
import StatsBar from "@/components/StatsBar";
import CalendarDrawer from "@/components/CalendarDrawer";
import { isToday, isFuture } from "date-fns";
import type { NewsArticle, FinancialEvent } from "@shared/schema";

interface Company {
  id: string;
  symbol: string;
  name: string;
  exchange: string;
  sector: string | null;
}

export default function Home() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCompany, setSelectedCompany] = useState<Company | null>(null);
  const [category, setCategory] = useState("all");
  const [source, setSource] = useState("all");
  const [sort, setSort] = useState("date-desc");
  const [isCalendarOpen, setIsCalendarOpen] = useState(false);
  
  const handleCompanySelect = (company: Company) => {
    setSelectedCompany(company);
    setSearchQuery(company.name);
  };
  
  const handleSearchChange = (value: string) => {
    setSearchQuery(value);
    if (!value) {
      setSelectedCompany(null);
    }
  };

  const buildArticlesUrl = () => {
    const params = new URLSearchParams();
    if (category && category !== "all") params.set("category", category);
    if (source && source !== "all") params.set("source", source);
    if (selectedCompany) {
      params.set("ticker", selectedCompany.symbol);
    } else if (searchQuery) {
      params.set("search", searchQuery);
    }
    if (sort) params.set("sort", sort);
    const queryString = params.toString();
    return `/api/articles${queryString ? `?${queryString}` : ""}`;
  };

  const { data: articles = [], isLoading: articlesLoading } = useQuery<NewsArticle[]>({
    queryKey: ["articles", category, source, searchQuery, selectedCompany?.symbol, sort],
    queryFn: async () => {
      const res = await fetch(buildArticlesUrl());
      if (!res.ok) throw new Error("Failed to fetch articles");
      return res.json();
    },
  });

  const { data: events = [] } = useQuery<FinancialEvent[]>({
    queryKey: ["/api/events"],
  });

  const todayArticles = articles.filter((a) => isToday(new Date(a.publishedAt))).length;
  const upcomingEvents = events.filter((e) => isFuture(new Date(e.date)) || isToday(new Date(e.date))).length;

  return (
    <div className="min-h-screen bg-background">
      <Header
        searchQuery={searchQuery}
        onSearchChange={handleSearchChange}
        onSearch={(q) => setSearchQuery(q)}
        onCalendarClick={() => setIsCalendarOpen(true)}
        onCompanySelect={handleCompanySelect}
      />

      <main className="max-w-7xl mx-auto px-4 md:px-8 py-6 space-y-6">
        <section>
          <h1 className="font-serif text-3xl md:text-4xl font-bold mb-2" data-testid="text-page-title">
            {selectedCompany ? selectedCompany.name : "Financial News"}
          </h1>
          <p className="text-muted-foreground">
            {selectedCompany 
              ? `${selectedCompany.symbol.replace(".NS", "")} • ${selectedCompany.exchange} • ${selectedCompany.sector || "Financials"}`
              : "Stay informed with curated news from global financial markets"
            }
          </p>
        </section>

        <StatsBar
          totalArticles={articles.length}
          todayArticles={todayArticles}
          upcomingEvents={upcomingEvents}
          marketTrend="up"
        />

        <FilterBar
          category={category}
          source={source}
          sort={sort}
          onCategoryChange={setCategory}
          onSourceChange={setSource}
          onSortChange={setSort}
        />

        <NewsFeed articles={articles} isLoading={articlesLoading} />
      </main>

      <CalendarDrawer
        isOpen={isCalendarOpen}
        onClose={() => setIsCalendarOpen(false)}
        events={events}
      />
    </div>
  );
}
