import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ExternalLink, TrendingUp } from "lucide-react";
import { format } from "date-fns";
import type { NewsArticle } from "@shared/schema";

interface NewsCardProps {
  article: NewsArticle;
  isExpanded?: boolean;
  onToggle?: () => void;
}

const categoryColors: Record<string, string> = {
  stocks: "bg-chart-1/10 text-chart-1",
  economy: "bg-chart-2/10 text-chart-2",
  finance: "bg-chart-3/10 text-chart-3",
  markets: "bg-chart-4/10 text-chart-4",
  global: "bg-chart-5/10 text-chart-5",
};

export default function NewsCard({ article, isExpanded, onToggle }: NewsCardProps) {
  const publishedDate = new Date(article.publishedAt);

  return (
    <Card 
      className="hover-elevate active-elevate-2 cursor-pointer transition-all"
      onClick={onToggle}
      data-testid={`card-news-${article.id}`}
    >
      <CardContent className="p-4">
        <div className="flex items-start justify-between gap-2 mb-2">
          <Badge 
            variant="secondary" 
            className={`text-xs uppercase tracking-wider ${categoryColors[article.category] || ""}`}
          >
            {article.category}
          </Badge>
          {article.ticker && (
            <Badge variant="outline" className="text-xs font-mono">
              {article.ticker}
            </Badge>
          )}
        </div>

        <h3 className="font-semibold text-foreground leading-tight mb-2 line-clamp-2" data-testid={`text-headline-${article.id}`}>
          {article.headline}
        </h3>

        <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
          <span className="font-medium">{article.source}</span>
          <span>•</span>
          <time dateTime={publishedDate.toISOString()}>
            {format(publishedDate, "MMM d, h:mm a")}
          </time>
        </div>

        {isExpanded && (
          <div className="mt-4 pt-4 border-t border-border space-y-3 animate-in fade-in slide-in-from-top-2 duration-200">
            <p className="text-sm text-muted-foreground leading-relaxed">
              {article.content}
            </p>
            
            {article.author && (
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <span>By</span>
                <span className="font-medium text-foreground">{article.author}</span>
              </div>
            )}

            <div className="flex items-center gap-4 pt-2">
              <a 
                href={article.sourceUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1 text-sm text-primary hover:underline"
                onClick={(e) => e.stopPropagation()}
                data-testid={`link-source-${article.id}`}
              >
                Read Full Article
                <ExternalLink className="h-3 w-3" />
              </a>
              
              {article.ticker && (
                <a 
                  href={`https://www.tradingview.com/symbols/NSE-${article.ticker}/`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 text-sm text-chart-2 hover:underline"
                  onClick={(e) => e.stopPropagation()}
                  data-testid={`link-chart-${article.id}`}
                >
                  View Chart
                  <TrendingUp className="h-3 w-3" />
                </a>
              )}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
