import { Search, X, Building2, TrendingUp } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useState, useEffect, useRef } from "react";
import { useQuery } from "@tanstack/react-query";

interface Company {
  id: string;
  symbol: string;
  name: string;
  exchange: string;
  sector: string | null;
}

interface SearchBarProps {
  value?: string;
  onChange?: (value: string) => void;
  onSearch?: (query: string) => void;
  onCompanySelect?: (company: Company) => void;
  placeholder?: string;
}

export default function SearchBar({ 
  value: controlledValue, 
  onChange, 
  onSearch,
  onCompanySelect,
  placeholder = "Search news, companies, topics..." 
}: SearchBarProps) {
  const [internalValue, setInternalValue] = useState("");
  const [showSuggestions, setShowSuggestions] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const suggestionsRef = useRef<HTMLDivElement>(null);
  
  const value = controlledValue ?? internalValue;
  
  const { data: companies = [] } = useQuery<Company[]>({
    queryKey: ["/api/companies/search", value],
    queryFn: async () => {
      if (!value || value.length < 2) return [];
      const res = await fetch(`/api/companies/search?q=${encodeURIComponent(value)}`);
      if (!res.ok) return [];
      return res.json();
    },
    enabled: value.length >= 2,
    staleTime: 30000,
  });
  
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        suggestionsRef.current && 
        !suggestionsRef.current.contains(event.target as Node) &&
        inputRef.current &&
        !inputRef.current.contains(event.target as Node)
      ) {
        setShowSuggestions(false);
      }
    };
    
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);
  
  const handleChange = (newValue: string) => {
    if (onChange) {
      onChange(newValue);
    } else {
      setInternalValue(newValue);
    }
    setShowSuggestions(newValue.length >= 2);
  };

  const handleClear = () => {
    handleChange("");
    setShowSuggestions(false);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setShowSuggestions(false);
    onSearch?.(value);
  };
  
  const handleCompanyClick = (company: Company) => {
    setShowSuggestions(false);
    if (onCompanySelect) {
      onCompanySelect(company);
    } else {
      handleChange(company.name);
      onSearch?.(company.name);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="relative flex-1 max-w-xl">
      <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
      <Input
        ref={inputRef}
        type="search"
        value={value}
        onChange={(e) => handleChange(e.target.value)}
        onFocus={() => value.length >= 2 && setShowSuggestions(true)}
        placeholder={placeholder}
        className="pl-10 pr-10"
        data-testid="input-search"
      />
      {value && (
        <Button
          type="button"
          variant="ghost"
          size="icon"
          className="absolute right-1 top-1/2 -translate-y-1/2 h-7 w-7"
          onClick={handleClear}
          data-testid="button-search-clear"
        >
          <X className="h-3 w-3" />
        </Button>
      )}
      
      {showSuggestions && companies.length > 0 && (
        <div 
          ref={suggestionsRef}
          className="absolute top-full left-0 right-0 mt-1 bg-background border rounded-lg shadow-lg z-50 max-h-80 overflow-auto"
        >
          <div className="p-2 text-xs text-muted-foreground border-b">
            Companies
          </div>
          {companies.map((company) => (
            <button
              key={company.id}
              type="button"
              onClick={() => handleCompanyClick(company)}
              className="w-full flex items-center gap-3 px-3 py-2 hover:bg-accent text-left transition-colors"
            >
              <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                <Building2 className="h-4 w-4 text-primary" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="font-medium text-sm truncate">{company.name}</div>
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <span className="font-mono">{company.symbol.replace(".NS", "")}</span>
                  {company.sector && (
                    <>
                      <span>•</span>
                      <span>{company.sector}</span>
                    </>
                  )}
                </div>
              </div>
              <TrendingUp className="h-4 w-4 text-muted-foreground flex-shrink-0" />
            </button>
          ))}
        </div>
      )}
    </form>
  );
}
