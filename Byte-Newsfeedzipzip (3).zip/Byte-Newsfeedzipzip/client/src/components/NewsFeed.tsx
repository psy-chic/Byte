import { useState } from "react";
import NewsCard from "./NewsCard";
import type { NewsArticle } from "@shared/schema";

interface NewsFeedProps {
  articles: NewsArticle[];
  isLoading?: boolean;
}

export default function NewsFeed({ articles, isLoading }: NewsFeedProps) {
  const [expandedId, setExpandedId] = useState<string | null>(null);

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {[...Array(6)].map((_, i) => (
          <div key={i} className="animate-pulse">
            <div className="bg-card rounded-lg p-4 space-y-3">
              <div className="flex justify-between">
                <div className="h-5 w-16 bg-muted rounded" />
                <div className="h-5 w-12 bg-muted rounded" />
              </div>
              <div className="h-6 w-full bg-muted rounded" />
              <div className="h-6 w-3/4 bg-muted rounded" />
              <div className="flex gap-2">
                <div className="h-4 w-16 bg-muted rounded" />
                <div className="h-4 w-24 bg-muted rounded" />
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (articles.length === 0) {
    return (
      <div className="text-center py-12">
        <p className="text-muted-foreground">No articles found matching your criteria.</p>
        <p className="text-sm text-muted-foreground mt-1">Try adjusting your filters or search query.</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4" data-testid="news-feed">
      {articles.map((article) => (
        <NewsCard
          key={article.id}
          article={article}
          isExpanded={expandedId === article.id}
          onToggle={() => setExpandedId(expandedId === article.id ? null : article.id)}
        />
      ))}
    </div>
  );
}
