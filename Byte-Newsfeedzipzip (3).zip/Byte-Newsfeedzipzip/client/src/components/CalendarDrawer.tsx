import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import FinancialCalendar from "./FinancialCalendar";
import type { FinancialEvent } from "@shared/schema";

interface CalendarDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  events: FinancialEvent[];
}

export default function CalendarDrawer({ isOpen, onClose, events }: CalendarDrawerProps) {
  return (
    <Sheet open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <SheetContent className="w-full sm:max-w-md">
        <SheetHeader>
          <SheetTitle className="font-serif">Financial Calendar</SheetTitle>
        </SheetHeader>
        <div className="mt-6">
          <FinancialCalendar 
            events={events}
            onDateSelect={(date) => console.log("Date selected:", date)}
          />
        </div>
      </SheetContent>
    </Sheet>
  );
}
