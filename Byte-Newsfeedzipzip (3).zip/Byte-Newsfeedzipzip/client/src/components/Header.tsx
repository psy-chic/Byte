import ByteLogo from "./ByteLogo";
import SearchBar from "./SearchBar";
import ThemeToggle from "./ThemeToggle";
import { Button } from "@/components/ui/button";
import { CalendarDays } from "lucide-react";

interface Company {
  id: string;
  symbol: string;
  name: string;
  exchange: string;
  sector: string | null;
}

interface HeaderProps {
  searchQuery: string;
  onSearchChange: (value: string) => void;
  onSearch: (query: string) => void;
  onCalendarClick?: () => void;
  onCompanySelect?: (company: Company) => void;
}

export default function Header({
  searchQuery,
  onSearchChange,
  onSearch,
  onCalendarClick,
  onCompanySelect,
}: HeaderProps) {
  return (
    <header className="sticky top-0 z-50 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b border-border">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        <div className="flex items-center justify-between gap-4 h-16">
          <ByteLogo size="md" />

          <SearchBar
            value={searchQuery}
            onChange={onSearchChange}
            onSearch={onSearch}
            onCompanySelect={onCompanySelect}
          />

          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={onCalendarClick}
              data-testid="button-calendar"
            >
              <CalendarDays className="h-4 w-4" />
            </Button>

            <ThemeToggle />
          </div>
        </div>
      </div>
    </header>
  );
}
