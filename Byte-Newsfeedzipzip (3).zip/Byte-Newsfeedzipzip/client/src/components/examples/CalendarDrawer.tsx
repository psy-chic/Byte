import CalendarDrawer from "../CalendarDrawer";
import { Button } from "@/components/ui/button";
import { useState } from "react";

const mockEvents = [
  {
    id: "e1",
    title: "RBI Monetary Policy Meeting",
    date: new Date("2024-12-11"),
    type: "policy",
    description: "Bi-monthly monetary policy review by Reserve Bank of India",
    createdAt: new Date(),
  },
  {
    id: "e2",
    title: "TCS Q3 Results",
    date: new Date("2024-12-12"),
    type: "earnings",
    description: "Tata Consultancy Services quarterly earnings announcement",
    createdAt: new Date(),
  },
];

export default function CalendarDrawerExample() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div>
      <Button onClick={() => setIsOpen(true)}>Open Calendar</Button>
      <CalendarDrawer
        isOpen={isOpen}
        onClose={() => setIsOpen(false)}
        events={mockEvents}
      />
    </div>
  );
}
