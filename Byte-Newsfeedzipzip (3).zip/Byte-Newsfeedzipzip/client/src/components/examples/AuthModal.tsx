import AuthModal from "../AuthModal";
import { useState } from "react";
import { Button } from "@/components/ui/button";

export default function AuthModalExample() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div>
      <Button onClick={() => setIsOpen(true)}>Open Auth Modal</Button>
      <AuthModal
        isOpen={isOpen}
        onClose={() => setIsOpen(false)}
        onLogin={(email, password) => {
          console.log("Login:", email, password);
          setIsOpen(false);
        }}
        onSignup={(email, password) => {
          console.log("Signup:", email, password);
          setIsOpen(false);
        }}
      />
    </div>
  );
}
