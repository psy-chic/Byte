import NewsCard from "../NewsCard";
import { useState } from "react";

const mockArticle = {
  id: "1",
  headline: "RBI Maintains Repo Rate at 6.5% Amid Inflation Concerns",
  summary: "The Reserve Bank of India held its key policy rate steady for the eighth consecutive time.",
  content: "The Reserve Bank of India's Monetary Policy Committee decided to maintain the repo rate at 6.5% as consumer price inflation continues to hover above the central bank's 4% target. Governor Shaktikanta Das emphasized the need for sustained vigilance on the inflation front while supporting economic growth.",
  source: "Mint",
  author: "Priya Sharma",
  publishedAt: new Date("2024-12-11T10:30:00"),
  category: "economy",
  ticker: null,
  imageUrl: null,
  sourceUrl: "https://livemint.com",
  createdAt: new Date(),
};

export default function NewsCardExample() {
  const [expanded, setExpanded] = useState(false);
  
  return (
    <div className="max-w-md">
      <NewsCard 
        article={mockArticle} 
        isExpanded={expanded}
        onToggle={() => setExpanded(!expanded)}
      />
    </div>
  );
}
