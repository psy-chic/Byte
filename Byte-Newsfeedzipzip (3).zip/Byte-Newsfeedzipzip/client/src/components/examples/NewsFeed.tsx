import NewsFeed from "../NewsFeed";

const mockArticles = [
  {
    id: "1",
    headline: "RBI Maintains Repo Rate at 6.5% Amid Inflation Concerns",
    summary: "The Reserve Bank of India held its key policy rate steady.",
    content: "The Reserve Bank of India's Monetary Policy Committee decided to maintain the repo rate at 6.5%.",
    source: "Mint",
    author: "Priya Sharma",
    publishedAt: new Date("2024-12-11T10:30:00"),
    category: "economy",
    ticker: null,
    imageUrl: null,
    sourceUrl: "https://livemint.com",
    createdAt: new Date(),
  },
  {
    id: "2",
    headline: "Nifty 50 Hits Record High as IT Stocks Rally",
    summary: "Indian benchmark indices surged to all-time highs.",
    content: "The Nifty 50 index crossed the 21,000 mark for the first time in history.",
    source: "Business Times",
    author: "Rajesh Kumar",
    publishedAt: new Date("2024-12-11T09:15:00"),
    category: "stocks",
    ticker: "NIFTY50",
    imageUrl: null,
    sourceUrl: "https://businesstimes.com",
    createdAt: new Date(),
  },
];

export default function NewsFeedExample() {
  return (
    <div className="w-full">
      <NewsFeed articles={mockArticles} />
    </div>
  );
}
