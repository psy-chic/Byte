import StatsBar from "../StatsBar";

export default function StatsBarExample() {
  return (
    <div className="w-full">
      <StatsBar
        totalArticles={1247}
        todayArticles={48}
        upcomingEvents={6}
        marketTrend="up"
      />
    </div>
  );
}
