import FilterBar from "../FilterBar";
import { useState } from "react";

export default function FilterBarExample() {
  const [category, setCategory] = useState("all");
  const [source, setSource] = useState("all");
  const [sort, setSort] = useState("date-desc");

  return (
    <div className="w-full">
      <FilterBar
        category={category}
        source={source}
        sort={sort}
        onCategoryChange={setCategory}
        onSourceChange={setSource}
        onSortChange={setSort}
      />
    </div>
  );
}
