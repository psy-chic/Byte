import Header from "../Header";
import { useState } from "react";

export default function HeaderExample() {
  const [query, setQuery] = useState("");
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  return (
    <div className="w-full">
      <Header
        searchQuery={query}
        onSearchChange={setQuery}
        onSearch={(q) => console.log("Search:", q)}
        isLoggedIn={isLoggedIn}
        userName="John"
        onLoginClick={() => setIsLoggedIn(true)}
        onLogoutClick={() => setIsLoggedIn(false)}
        onCalendarClick={() => console.log("Calendar clicked")}
      />
    </div>
  );
}
