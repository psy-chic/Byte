import SearchBar from "../SearchBar";
import { useState } from "react";

export default function SearchBarExample() {
  const [query, setQuery] = useState("");
  
  return (
    <div className="w-full max-w-md">
      <SearchBar 
        value={query} 
        onChange={setQuery}
        onSearch={(q) => console.log("Searching:", q)}
      />
    </div>
  );
}
