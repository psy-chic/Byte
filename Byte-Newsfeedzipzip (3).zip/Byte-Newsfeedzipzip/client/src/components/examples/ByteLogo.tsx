import ByteLogo from "../ByteLogo";

export default function ByteLogoExample() {
  return (
    <div className="flex items-center gap-8">
      <ByteLogo size="sm" />
      <ByteLogo size="md" />
      <ByteLogo size="lg" />
    </div>
  );
}
