import { Card, CardContent } from "@/components/ui/card";
import { TrendingUp, TrendingDown, Newspaper, Calendar } from "lucide-react";

interface StatsBarProps {
  totalArticles: number;
  todayArticles: number;
  upcomingEvents: number;
  marketTrend?: "up" | "down" | "neutral";
}

export default function StatsBar({ 
  totalArticles, 
  todayArticles, 
  upcomingEvents,
  marketTrend = "neutral"
}: StatsBarProps) {
  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      <Card>
        <CardContent className="p-4 flex items-center gap-3">
          <div className="p-2 rounded-md bg-chart-1/10">
            <Newspaper className="h-5 w-5 text-chart-1" />
          </div>
          <div>
            <p className="text-2xl font-semibold" data-testid="stat-total-articles">{totalArticles}</p>
            <p className="text-xs text-muted-foreground">Total Articles</p>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-4 flex items-center gap-3">
          <div className="p-2 rounded-md bg-chart-2/10">
            <Newspaper className="h-5 w-5 text-chart-2" />
          </div>
          <div>
            <p className="text-2xl font-semibold" data-testid="stat-today-articles">{todayArticles}</p>
            <p className="text-xs text-muted-foreground">Today</p>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-4 flex items-center gap-3">
          <div className="p-2 rounded-md bg-chart-3/10">
            <Calendar className="h-5 w-5 text-chart-3" />
          </div>
          <div>
            <p className="text-2xl font-semibold" data-testid="stat-upcoming-events">{upcomingEvents}</p>
            <p className="text-xs text-muted-foreground">Upcoming Events</p>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-4 flex items-center gap-3">
          <div className={`p-2 rounded-md ${marketTrend === "up" ? "bg-chart-4/10" : marketTrend === "down" ? "bg-destructive/10" : "bg-muted"}`}>
            {marketTrend === "up" ? (
              <TrendingUp className="h-5 w-5 text-chart-4" />
            ) : marketTrend === "down" ? (
              <TrendingDown className="h-5 w-5 text-destructive" />
            ) : (
              <TrendingUp className="h-5 w-5 text-muted-foreground" />
            )}
          </div>
          <div>
            <p className="text-2xl font-semibold" data-testid="stat-market-trend">
              {marketTrend === "up" ? "Bullish" : marketTrend === "down" ? "Bearish" : "Mixed"}
            </p>
            <p className="text-xs text-muted-foreground">Market Trend</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
