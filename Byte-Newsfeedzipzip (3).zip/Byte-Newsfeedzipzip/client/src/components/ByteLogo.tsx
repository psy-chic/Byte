interface ByteLogoProps {
  size?: "sm" | "md" | "lg";
  className?: string;
}

export default function ByteLogo({ size = "md", className = "" }: ByteLogoProps) {
  const sizeClasses = {
    sm: "text-xl",
    md: "text-2xl",
    lg: "text-4xl",
  };

  return (
    <span className={`font-serif font-bold tracking-tight ${sizeClasses[size]} ${className}`} data-testid="logo-byte">
      <span className="text-primary">B</span>
      <span className="text-foreground">yte</span>
    </span>
  );
}
