import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { newsCategories, newsSources, sortOptions } from "@/lib/mockData";

interface FilterBarProps {
  category: string;
  source: string;
  sort: string;
  onCategoryChange: (value: string) => void;
  onSourceChange: (value: string) => void;
  onSortChange: (value: string) => void;
}

export default function FilterBar({
  category,
  source,
  sort,
  onCategoryChange,
  onSourceChange,
  onSortChange,
}: FilterBarProps) {
  return (
    <div className="flex flex-wrap items-center gap-3">
      <div className="flex items-center gap-2 overflow-x-auto pb-1">
        {newsCategories.map((cat) => (
          <Button
            key={cat.id}
            variant={category === cat.id ? "default" : "outline"}
            size="sm"
            onClick={() => onCategoryChange(cat.id)}
            data-testid={`button-category-${cat.id}`}
          >
            {cat.label}
          </Button>
        ))}
      </div>

      <div className="flex items-center gap-2 ml-auto">
        <Select value={source} onValueChange={onSourceChange}>
          <SelectTrigger className="w-[140px]" data-testid="select-source">
            <SelectValue placeholder="Source" />
          </SelectTrigger>
          <SelectContent>
            {newsSources.map((src) => (
              <SelectItem key={src.id} value={src.id}>
                {src.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select value={sort} onValueChange={onSortChange}>
          <SelectTrigger className="w-[140px]" data-testid="select-sort">
            <SelectValue placeholder="Sort by" />
          </SelectTrigger>
          <SelectContent>
            {sortOptions.map((opt) => (
              <SelectItem key={opt.id} value={opt.id}>
                {opt.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
    </div>
  );
}
