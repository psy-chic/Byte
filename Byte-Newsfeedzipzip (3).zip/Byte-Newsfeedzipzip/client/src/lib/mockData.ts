// todo: remove mock functionality - replace with real API data

export interface NewsArticle {
  id: string;
  headline: string;
  summary: string;
  content: string;
  source: string;
  author: string;
  publishedAt: Date;
  category: "stocks" | "economy" | "finance" | "markets" | "global";
  ticker?: string;
  imageUrl?: string;
  sourceUrl: string;
}

export interface FinancialEvent {
  id: string;
  title: string;
  date: Date;
  type: "earnings" | "dividend" | "ipo" | "policy" | "report";
  description: string;
}

// todo: remove mock functionality
export const mockArticles: NewsArticle[] = [
  {
    id: "1",
    headline: "RBI Maintains Repo Rate at 6.5% Amid Inflation Concerns",
    summary: "The Reserve Bank of India held its key policy rate steady for the eighth consecutive time as inflation remains above target.",
    content: "The Reserve Bank of India's Monetary Policy Committee decided to maintain the repo rate at 6.5% as consumer price inflation continues to hover above the central bank's 4% target. Governor Shaktikanta Das emphasized the need for sustained vigilance on the inflation front while supporting economic growth.",
    source: "Mint",
    author: "Priya Sharma",
    publishedAt: new Date("2024-12-11T10:30:00"),
    category: "economy",
    sourceUrl: "https://livemint.com",
  },
  {
    id: "2",
    headline: "Nifty 50 Hits Record High as IT Stocks Rally",
    summary: "Indian benchmark indices surged to all-time highs driven by strong performance in technology and banking sectors.",
    content: "The Nifty 50 index crossed the 21,000 mark for the first time in history, propelled by robust buying in IT heavyweights TCS, Infosys, and Wipro. Foreign institutional investors continued their buying spree, pumping in over Rs 5,000 crore in the past week.",
    source: "Business Times",
    author: "Rajesh Kumar",
    publishedAt: new Date("2024-12-11T09:15:00"),
    category: "stocks",
    ticker: "NIFTY50",
    sourceUrl: "https://businesstimes.com",
  },
  {
    id: "3",
    headline: "Reliance Industries Plans Major Green Energy Investment",
    summary: "RIL announces Rs 75,000 crore investment in renewable energy projects over the next five years.",
    content: "Mukesh Ambani-led Reliance Industries unveiled an ambitious green energy roadmap, committing Rs 75,000 crore towards solar manufacturing, hydrogen production, and energy storage solutions. The company aims to achieve net-zero carbon emissions by 2035.",
    source: "TOI",
    author: "Anita Desai",
    publishedAt: new Date("2024-12-10T16:45:00"),
    category: "finance",
    ticker: "RELIANCE",
    sourceUrl: "https://timesofindia.com",
  },
  {
    id: "4",
    headline: "US Federal Reserve Signals Rate Cuts in Early 2025",
    summary: "Fed officials hint at potential monetary policy easing as inflation shows sustained decline.",
    content: "Federal Reserve policymakers indicated they may begin cutting interest rates in the first quarter of 2025, citing cooling inflation and a stabilizing labor market. The announcement sent global markets higher, with emerging market currencies strengthening against the dollar.",
    source: "Business Times",
    author: "Michael Chen",
    publishedAt: new Date("2024-12-10T14:20:00"),
    category: "global",
    sourceUrl: "https://businesstimes.com",
  },
  {
    id: "5",
    headline: "HDFC Bank Reports 20% Growth in Q3 Net Profit",
    summary: "India's largest private sector bank beats analyst estimates with strong loan growth and improved asset quality.",
    content: "HDFC Bank reported a 20% year-on-year increase in net profit for the October-December quarter, driven by robust loan growth across retail and corporate segments. The bank's asset quality improved with gross NPA falling to 1.26% from 1.35% in the previous quarter.",
    source: "Mint",
    author: "Vikram Mehta",
    publishedAt: new Date("2024-12-10T11:00:00"),
    category: "stocks",
    ticker: "HDFCBANK",
    sourceUrl: "https://livemint.com",
  },
  {
    id: "6",
    headline: "Oil Prices Surge Amid Middle East Tensions",
    summary: "Brent crude jumps 4% as geopolitical risks heighten supply concerns.",
    content: "Global oil prices rallied sharply with Brent crude crossing $85 per barrel as escalating tensions in the Middle East raised concerns about potential supply disruptions. Indian oil marketing companies may face margin pressures if prices sustain at elevated levels.",
    source: "TOI",
    author: "Suresh Nair",
    publishedAt: new Date("2024-12-09T18:30:00"),
    category: "markets",
    sourceUrl: "https://timesofindia.com",
  },
  {
    id: "7",
    headline: "Tata Motors Electric Vehicle Sales Double in November",
    summary: "EV market leader Tata Motors reports 102% growth in electric vehicle dispatches.",
    content: "Tata Motors sold over 8,500 electric vehicles in November, more than doubling from the same month last year. The Nexon EV and Punch EV continue to dominate the Indian EV market, with the company commanding over 60% market share.",
    source: "Business Times",
    author: "Kavita Rao",
    publishedAt: new Date("2024-12-09T15:45:00"),
    category: "stocks",
    ticker: "TATAMOTORS",
    sourceUrl: "https://businesstimes.com",
  },
  {
    id: "8",
    headline: "India's GDP Growth Exceeds 7% in Q2 FY25",
    summary: "Strong manufacturing and services sectors drive robust economic expansion.",
    content: "India's economy grew at 7.2% in the July-September quarter, surpassing market expectations of 6.8%. The manufacturing sector expanded 8.1% while services growth remained strong at 7.5%. Government capital expenditure provided additional momentum to economic activity.",
    source: "Mint",
    author: "Deepak Sharma",
    publishedAt: new Date("2024-12-09T10:00:00"),
    category: "economy",
    sourceUrl: "https://livemint.com",
  },
];

// todo: remove mock functionality
export const mockEvents: FinancialEvent[] = [
  {
    id: "e1",
    title: "RBI Monetary Policy Meeting",
    date: new Date("2024-12-11"),
    type: "policy",
    description: "Bi-monthly monetary policy review by Reserve Bank of India",
  },
  {
    id: "e2",
    title: "TCS Q3 Results",
    date: new Date("2024-12-12"),
    type: "earnings",
    description: "Tata Consultancy Services quarterly earnings announcement",
  },
  {
    id: "e3",
    title: "Infosys Q3 Results",
    date: new Date("2024-12-13"),
    type: "earnings",
    description: "Infosys quarterly earnings announcement",
  },
  {
    id: "e4",
    title: "US Fed Interest Rate Decision",
    date: new Date("2024-12-14"),
    type: "policy",
    description: "Federal Reserve FOMC meeting conclusion",
  },
  {
    id: "e5",
    title: "HDFC Bank Dividend",
    date: new Date("2024-12-18"),
    type: "dividend",
    description: "Ex-dividend date for HDFC Bank interim dividend",
  },
  {
    id: "e6",
    title: "New IPO: Swiggy",
    date: new Date("2024-12-20"),
    type: "ipo",
    description: "Swiggy IPO subscription opens",
  },
];

export const newsCategories = [
  { id: "all", label: "All News" },
  { id: "stocks", label: "NSE Stocks" },
  { id: "economy", label: "Economy" },
  { id: "finance", label: "Finance" },
  { id: "markets", label: "Markets" },
  { id: "global", label: "Global" },
] as const;

export const newsSources = [
  { id: "all", label: "All Sources" },
  { id: "Reuters", label: "Reuters" },
  { id: "Bloomberg", label: "Bloomberg" },
  { id: "CNBC", label: "CNBC" },
  { id: "Yahoo Finance", label: "Yahoo Finance" },
  { id: "MarketWatch", label: "MarketWatch" },
  { id: "Financial Times", label: "Financial Times" },
  { id: "Wall Street Journal", label: "WSJ" },
  { id: "Forbes", label: "Forbes" },
  { id: "Business Insider", label: "Business Insider" },
  { id: "Google News", label: "Google News" },
] as const;

export const sortOptions = [
  { id: "date-desc", label: "Newest First" },
  { id: "date-asc", label: "Oldest First" },
  { id: "relevance", label: "Relevance" },
] as const;
