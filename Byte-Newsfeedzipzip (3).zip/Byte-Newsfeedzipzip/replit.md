# Byte - Financial News Aggregation Platform

## Overview

Byte is a professional financial news aggregation platform that collects and displays news from global financial sources including TOI, Business Times, and Mint. The application provides users with personalized news feeds, financial calendars, and market insights with a design inspired by Bloomberg Terminal's data density and Financial Times' editorial clarity.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack React Query for server state and caching
- **Styling**: Tailwind CSS with shadcn/ui component library (New York style variant)
- **Build Tool**: Vite with HMR support for development

The frontend follows a component-based architecture with:
- Reusable UI components in `client/src/components/ui/` (shadcn/ui primitives)
- Feature components in `client/src/components/` (Header, NewsFeed, FilterBar, etc.)
- Page components in `client/src/pages/` (Home, Landing, NotFound)
- Custom hooks in `client/src/hooks/` for authentication and theme management

### Backend Architecture
- **Runtime**: Node.js with Express
- **Language**: TypeScript with ESM modules
- **API Design**: RESTful endpoints under `/api/` prefix
- **Authentication**: Replit Auth with OpenID Connect, session-based with PostgreSQL session store
- **Database ORM**: Drizzle ORM with PostgreSQL

The server follows a modular structure:
- `server/index.ts`: Express app setup and middleware configuration
- `server/routes.ts`: API route definitions
- `server/storage.ts`: Data access layer with typed interfaces
- `server/replitAuth.ts`: Authentication configuration with Passport.js

### Data Storage
- **Database**: PostgreSQL with Drizzle ORM
- **Schema Location**: `shared/schema.ts` (shared between client and server)
- **Session Storage**: PostgreSQL via connect-pg-simple
- **Key Tables**: users, sessions, newsArticles, financialEvents, userPreferences, savedArticles, readingHistory

### Authentication Flow
- Uses Replit's OpenID Connect provider for user authentication
- Sessions stored in PostgreSQL with 1-week TTL
- Protected routes use `isAuthenticated` middleware
- User data synchronized on login via `upsertUser`

### Design System
- Typography: Merriweather (serif) for headlines, Poppins (sans-serif) for body text
- Color scheme: HSL-based CSS variables with light/dark mode support
- Component styling follows shadcn/ui patterns with custom theme extensions
- Elevation system using CSS shadows for interactive feedback

## External Dependencies

### Third-Party Services
- **Replit Auth**: OpenID Connect authentication provider (configured via ISSUER_URL)
- **PostgreSQL**: Primary database (configured via DATABASE_URL)

### Key NPM Packages
- **Frontend**: @tanstack/react-query, wouter, date-fns, lucide-react, embla-carousel-react
- **Backend**: express, passport, express-session, drizzle-orm, pg
- **UI Components**: Full shadcn/ui suite (@radix-ui primitives, class-variance-authority)
- **Validation**: zod, drizzle-zod for schema validation

### Environment Variables Required
- `DATABASE_URL`: PostgreSQL connection string
- `SESSION_SECRET`: Secret for session encryption
- `REPL_ID`: Replit environment identifier (auto-set in Replit)
- `ISSUER_URL`: OpenID Connect issuer (defaults to Replit's OIDC)