import type { Express } from "express";
import { type Server } from "http";
import { storage } from "./storage";
import { refreshNews } from "./newsService";
import { searchCompanies, getCompanyBySymbol, getCompanyNews, getAllCompanies, fetchCompanyNews } from "./companyService";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  app.post("/api/refresh-news", async (req, res) => {
    try {
      await refreshNews();
      res.json({ success: true, message: "News refreshed successfully" });
    } catch (error) {
      console.error("Error refreshing news:", error);
      res.status(500).json({ message: "Failed to refresh news" });
    }
  });

  app.get("/api/articles", async (req, res) => {
    try {
      const { category, source, search, ticker, sort, limit, offset } = req.query;
      const articles = await storage.getArticles({
        category: category as string,
        source: source as string,
        search: search as string,
        ticker: ticker as string,
        sort: sort as string,
        limit: limit ? parseInt(limit as string) : undefined,
        offset: offset ? parseInt(offset as string) : undefined,
      });
      res.json(articles);
    } catch (error) {
      console.error("Error fetching articles:", error);
      res.status(500).json({ message: "Failed to fetch articles" });
    }
  });

  app.get("/api/articles/count", async (req, res) => {
    try {
      const { category, source } = req.query;
      const count = await storage.getArticleCount({
        category: category as string,
        source: source as string,
      });
      res.json({ count });
    } catch (error) {
      console.error("Error fetching article count:", error);
      res.status(500).json({ message: "Failed to fetch count" });
    }
  });

  app.get("/api/articles/:id", async (req, res) => {
    try {
      const article = await storage.getArticle(req.params.id);
      if (!article) {
        return res.status(404).json({ message: "Article not found" });
      }
      res.json(article);
    } catch (error) {
      console.error("Error fetching article:", error);
      res.status(500).json({ message: "Failed to fetch article" });
    }
  });

  app.get("/api/events", async (req, res) => {
    try {
      const { startDate, endDate, type } = req.query;
      const events = await storage.getEvents({
        startDate: startDate ? new Date(startDate as string) : undefined,
        endDate: endDate ? new Date(endDate as string) : undefined,
        type: type as string,
      });
      res.json(events);
    } catch (error) {
      console.error("Error fetching events:", error);
      res.status(500).json({ message: "Failed to fetch events" });
    }
  });

  app.get("/api/companies", async (req, res) => {
    try {
      const companies = await getAllCompanies();
      res.json(companies);
    } catch (error) {
      console.error("Error fetching companies:", error);
      res.status(500).json({ message: "Failed to fetch companies" });
    }
  });

  app.get("/api/companies/search", async (req, res) => {
    try {
      const { q } = req.query;
      if (!q || typeof q !== "string") {
        return res.json([]);
      }
      const results = await searchCompanies(q);
      res.json(results);
    } catch (error) {
      console.error("Error searching companies:", error);
      res.status(500).json({ message: "Failed to search companies" });
    }
  });

  app.get("/api/companies/:symbol", async (req, res) => {
    try {
      const company = await getCompanyBySymbol(req.params.symbol);
      if (!company) {
        return res.status(404).json({ message: "Company not found" });
      }
      res.json(company);
    } catch (error) {
      console.error("Error fetching company:", error);
      res.status(500).json({ message: "Failed to fetch company" });
    }
  });

  app.get("/api/companies/:symbol/news", async (req, res) => {
    try {
      const news = await getCompanyNews(req.params.symbol);
      res.json(news);
    } catch (error) {
      console.error("Error fetching company news:", error);
      res.status(500).json({ message: "Failed to fetch company news" });
    }
  });

  app.post("/api/companies/:symbol/fetch-news", async (req, res) => {
    try {
      const count = await fetchCompanyNews(req.params.symbol);
      res.json({ success: true, count });
    } catch (error) {
      console.error("Error fetching company news:", error);
      res.status(500).json({ message: "Failed to fetch company news" });
    }
  });

  return httpServer;
}
