import { db } from "./db";
import { newsArticles } from "@shared/schema";
import { eq } from "drizzle-orm";
import { randomUUID } from "crypto";

interface FinnhubNews {
  category: string;
  datetime: number;
  headline: string;
  id: number;
  image: string;
  related: string;
  source: string;
  summary: string;
  url: string;
}

const FINNHUB_API_KEY = process.env.FINNHUB_API_KEY || "demo";

const categoryMapping: Record<string, string> = {
  "general": "markets",
  "forex": "finance",
  "crypto": "markets",
  "merger": "finance",
  "business": "economy",
  "technology": "stocks",
  "healthcare": "stocks",
  "energy": "markets",
  "consumer": "economy",
  "financial": "finance",
  "industrial": "stocks",
  "realestate": "finance",
};

function mapCategory(finnhubCategory: string): string {
  const normalized = finnhubCategory.toLowerCase();
  return categoryMapping[normalized] || "markets";
}

export async function fetchAndStoreNews(): Promise<number> {
  try {
    console.log("Fetching news from Finnhub...");
    
    const categories = ["general", "forex", "crypto", "merger"];
    let totalInserted = 0;

    for (const category of categories) {
      const url = `https://finnhub.io/api/v1/news?category=${category}&token=${FINNHUB_API_KEY}`;
      
      const response = await fetch(url);
      
      if (!response.ok) {
        console.error(`Failed to fetch ${category} news: ${response.status}`);
        continue;
      }

      const news: FinnhubNews[] = await response.json();
      
      for (const item of news.slice(0, 15)) {
        try {
          const existingArticle = await db
            .select()
            .from(newsArticles)
            .where(eq(newsArticles.sourceUrl, item.url))
            .limit(1);

          if (existingArticle.length > 0) continue;

          await db.insert(newsArticles).values({
            id: randomUUID(),
            headline: item.headline,
            summary: item.summary || item.headline,
            content: item.summary || item.headline,
            source: item.source || "Finnhub",
            author: item.source || "Staff Reporter",
            publishedAt: new Date(item.datetime * 1000),
            category: mapCategory(category),
            ticker: item.related || null,
            imageUrl: item.image || null,
            sourceUrl: item.url,
          });
          totalInserted++;
        } catch (insertError) {
          console.error("Error inserting article:", insertError);
        }
      }
    }

    console.log(`Inserted ${totalInserted} new articles`);
    return totalInserted;
  } catch (error) {
    console.error("Error fetching news:", error);
    return 0;
  }
}

export async function fetchGoogleNews(): Promise<number> {
  try {
    console.log("Fetching news from Google News RSS...");
    
    const topics = [
      { query: "stock market", category: "stocks" },
      { query: "finance business", category: "finance" },
      { query: "economy gdp inflation", category: "economy" },
      { query: "cryptocurrency bitcoin", category: "markets" },
      { query: "global markets forex", category: "global" },
    ];

    let totalInserted = 0;

    for (const topic of topics) {
      try {
        const encodedQuery = encodeURIComponent(topic.query);
        const rssUrl = `https://news.google.com/rss/search?q=${encodedQuery}+when:7d&hl=en-US&gl=US&ceid=US:en`;
        
        const response = await fetch(rssUrl);
        if (!response.ok) continue;

        const xml = await response.text();
        const items = parseRssItems(xml);

        for (const item of items.slice(0, 10)) {
          try {
            await db.insert(newsArticles).values({
              id: randomUUID(),
              headline: item.title,
              summary: item.description || item.title,
              content: item.description || item.title,
              source: item.source || "Google News",
              author: item.source || "Staff",
              publishedAt: new Date(item.pubDate),
              category: topic.category,
              ticker: null,
              imageUrl: null,
              sourceUrl: item.link,
            });
            totalInserted++;
          } catch {
          }
        }
      } catch (topicError) {
        console.error(`Error fetching topic ${topic.query}:`, topicError);
      }
    }

    console.log(`Inserted ${totalInserted} articles from Google News`);
    return totalInserted;
  } catch (error) {
    console.error("Error fetching Google News:", error);
    return 0;
  }
}

function parseRssItems(xml: string): Array<{ title: string; description: string; link: string; pubDate: string; source: string }> {
  const items: Array<{ title: string; description: string; link: string; pubDate: string; source: string }> = [];
  
  const itemMatches = xml.match(/<item>([\s\S]*?)<\/item>/g);
  if (!itemMatches) return items;

  for (const itemXml of itemMatches) {
    const title = extractTag(itemXml, "title");
    const description = extractTag(itemXml, "description");
    const link = extractTag(itemXml, "link");
    const pubDate = extractTag(itemXml, "pubDate");
    const source = extractTag(itemXml, "source");

    if (title && link) {
      items.push({
        title: cleanHtml(title),
        description: cleanHtml(description || ""),
        link,
        pubDate: pubDate || new Date().toISOString(),
        source: source || "News",
      });
    }
  }

  return items;
}

function extractTag(xml: string, tag: string): string {
  const match = xml.match(new RegExp(`<${tag}[^>]*>([\\s\\S]*?)<\\/${tag}>`, "i"));
  if (match) {
    return match[1].replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, "$1").trim();
  }
  return "";
}

function cleanHtml(text: string): string {
  return text
    .replace(/<[^>]*>/g, "")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&nbsp;/g, " ")
    .trim();
}

export async function refreshNews(): Promise<number> {
  return await fetchGoogleNews();
}
