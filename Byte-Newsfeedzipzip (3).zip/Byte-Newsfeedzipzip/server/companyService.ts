import { db } from "./db";
import { companies, newsArticles } from "@shared/schema";
import { eq, ilike, or, desc } from "drizzle-orm";
import { randomUUID } from "crypto";

const FINNHUB_API_KEY = process.env.FINNHUB_API_KEY || "demo";

interface FinnhubSymbol {
  symbol: string;
  description: string;
  displaySymbol: string;
  type: string;
}

interface FinnhubCompanyProfile {
  country: string;
  currency: string;
  exchange: string;
  finnhubIndustry: string;
  ipo: string;
  logo: string;
  marketCapitalization: number;
  name: string;
  phone: string;
  shareOutstanding: number;
  ticker: string;
  weburl: string;
}

interface FinnhubCompanyNews {
  category: string;
  datetime: number;
  headline: string;
  id: number;
  image: string;
  related: string;
  source: string;
  summary: string;
  url: string;
}

const INDIAN_STOCKS = [
  { symbol: "RELIANCE.NS", name: "Reliance Industries Ltd", exchange: "NSE", sector: "Energy" },
  { symbol: "TCS.NS", name: "Tata Consultancy Services Ltd", exchange: "NSE", sector: "Technology" },
  { symbol: "HDFCBANK.NS", name: "HDFC Bank Ltd", exchange: "NSE", sector: "Banking" },
  { symbol: "INFY.NS", name: "Infosys Ltd", exchange: "NSE", sector: "Technology" },
  { symbol: "ICICIBANK.NS", name: "ICICI Bank Ltd", exchange: "NSE", sector: "Banking" },
  { symbol: "HINDUNILVR.NS", name: "Hindustan Unilever Ltd", exchange: "NSE", sector: "Consumer Goods" },
  { symbol: "ITC.NS", name: "ITC Ltd", exchange: "NSE", sector: "Consumer Goods" },
  { symbol: "SBIN.NS", name: "State Bank of India", exchange: "NSE", sector: "Banking" },
  { symbol: "BHARTIARTL.NS", name: "Bharti Airtel Ltd", exchange: "NSE", sector: "Telecom" },
  { symbol: "KOTAKBANK.NS", name: "Kotak Mahindra Bank Ltd", exchange: "NSE", sector: "Banking" },
  { symbol: "LT.NS", name: "Larsen & Toubro Ltd", exchange: "NSE", sector: "Infrastructure" },
  { symbol: "AXISBANK.NS", name: "Axis Bank Ltd", exchange: "NSE", sector: "Banking" },
  { symbol: "ASIANPAINT.NS", name: "Asian Paints Ltd", exchange: "NSE", sector: "Consumer Goods" },
  { symbol: "MARUTI.NS", name: "Maruti Suzuki India Ltd", exchange: "NSE", sector: "Automobile" },
  { symbol: "BAJFINANCE.NS", name: "Bajaj Finance Ltd", exchange: "NSE", sector: "Finance" },
  { symbol: "HCLTECH.NS", name: "HCL Technologies Ltd", exchange: "NSE", sector: "Technology" },
  { symbol: "WIPRO.NS", name: "Wipro Ltd", exchange: "NSE", sector: "Technology" },
  { symbol: "SUNPHARMA.NS", name: "Sun Pharmaceutical Industries Ltd", exchange: "NSE", sector: "Healthcare" },
  { symbol: "TITAN.NS", name: "Titan Company Ltd", exchange: "NSE", sector: "Consumer Goods" },
  { symbol: "ULTRACEMCO.NS", name: "UltraTech Cement Ltd", exchange: "NSE", sector: "Cement" },
  { symbol: "POWERGRID.NS", name: "Power Grid Corporation of India Ltd", exchange: "NSE", sector: "Utilities" },
  { symbol: "NTPC.NS", name: "NTPC Ltd", exchange: "NSE", sector: "Utilities" },
  { symbol: "TATAMOTORS.NS", name: "Tata Motors Ltd", exchange: "NSE", sector: "Automobile" },
  { symbol: "TATASTEEL.NS", name: "Tata Steel Ltd", exchange: "NSE", sector: "Metals" },
  { symbol: "ONGC.NS", name: "Oil and Natural Gas Corporation Ltd", exchange: "NSE", sector: "Energy" },
  { symbol: "COALINDIA.NS", name: "Coal India Ltd", exchange: "NSE", sector: "Mining" },
  { symbol: "ADANIENT.NS", name: "Adani Enterprises Ltd", exchange: "NSE", sector: "Conglomerate" },
  { symbol: "ADANIPORTS.NS", name: "Adani Ports and SEZ Ltd", exchange: "NSE", sector: "Infrastructure" },
  { symbol: "JSWSTEEL.NS", name: "JSW Steel Ltd", exchange: "NSE", sector: "Metals" },
  { symbol: "TECHM.NS", name: "Tech Mahindra Ltd", exchange: "NSE", sector: "Technology" },
  { symbol: "M&M.NS", name: "Mahindra & Mahindra Ltd", exchange: "NSE", sector: "Automobile" },
  { symbol: "DRREDDY.NS", name: "Dr. Reddy's Laboratories Ltd", exchange: "NSE", sector: "Healthcare" },
  { symbol: "BAJAJFINSV.NS", name: "Bajaj Finserv Ltd", exchange: "NSE", sector: "Finance" },
  { symbol: "NESTLEIND.NS", name: "Nestle India Ltd", exchange: "NSE", sector: "Consumer Goods" },
  { symbol: "DIVISLAB.NS", name: "Divi's Laboratories Ltd", exchange: "NSE", sector: "Healthcare" },
  { symbol: "CIPLA.NS", name: "Cipla Ltd", exchange: "NSE", sector: "Healthcare" },
  { symbol: "GRASIM.NS", name: "Grasim Industries Ltd", exchange: "NSE", sector: "Cement" },
  { symbol: "HEROMOTOCO.NS", name: "Hero MotoCorp Ltd", exchange: "NSE", sector: "Automobile" },
  { symbol: "EICHERMOT.NS", name: "Eicher Motors Ltd", exchange: "NSE", sector: "Automobile" },
  { symbol: "SHREECEM.NS", name: "Shree Cement Ltd", exchange: "NSE", sector: "Cement" },
  { symbol: "BRITANNIA.NS", name: "Britannia Industries Ltd", exchange: "NSE", sector: "Consumer Goods" },
  { symbol: "INDUSINDBK.NS", name: "IndusInd Bank Ltd", exchange: "NSE", sector: "Banking" },
  { symbol: "APOLLOHOSP.NS", name: "Apollo Hospitals Enterprise Ltd", exchange: "NSE", sector: "Healthcare" },
  { symbol: "HINDALCO.NS", name: "Hindalco Industries Ltd", exchange: "NSE", sector: "Metals" },
  { symbol: "TATACONSUM.NS", name: "Tata Consumer Products Ltd", exchange: "NSE", sector: "Consumer Goods" },
  { symbol: "BPCL.NS", name: "Bharat Petroleum Corporation Ltd", exchange: "NSE", sector: "Energy" },
  { symbol: "VEDL.NS", name: "Vedanta Ltd", exchange: "NSE", sector: "Metals" },
  { symbol: "ZOMATO.NS", name: "Zomato Ltd", exchange: "NSE", sector: "Technology" },
  { symbol: "PAYTM.NS", name: "One97 Communications Ltd (Paytm)", exchange: "NSE", sector: "Technology" },
  { symbol: "NYKAA.NS", name: "FSN E-Commerce Ventures Ltd (Nykaa)", exchange: "NSE", sector: "E-Commerce" },
  { symbol: "POLICYBZR.NS", name: "PB Fintech Ltd (PolicyBazaar)", exchange: "NSE", sector: "Finance" },
  { symbol: "DELHIVERY.NS", name: "Delhivery Ltd", exchange: "NSE", sector: "Logistics" },
  { symbol: "ADANIGREEN.NS", name: "Adani Green Energy Ltd", exchange: "NSE", sector: "Renewable Energy" },
  { symbol: "ADANIPOWER.NS", name: "Adani Power Ltd", exchange: "NSE", sector: "Utilities" },
  { symbol: "SBILIFE.NS", name: "SBI Life Insurance Company Ltd", exchange: "NSE", sector: "Insurance" },
  { symbol: "HDFCLIFE.NS", name: "HDFC Life Insurance Company Ltd", exchange: "NSE", sector: "Insurance" },
  { symbol: "ICICIGI.NS", name: "ICICI Lombard General Insurance Co Ltd", exchange: "NSE", sector: "Insurance" },
  { symbol: "BAJAJ-AUTO.NS", name: "Bajaj Auto Ltd", exchange: "NSE", sector: "Automobile" },
  { symbol: "PIDILITIND.NS", name: "Pidilite Industries Ltd", exchange: "NSE", sector: "Chemicals" },
  { symbol: "DABUR.NS", name: "Dabur India Ltd", exchange: "NSE", sector: "Consumer Goods" },
  { symbol: "MARICO.NS", name: "Marico Ltd", exchange: "NSE", sector: "Consumer Goods" },
  { symbol: "GODREJCP.NS", name: "Godrej Consumer Products Ltd", exchange: "NSE", sector: "Consumer Goods" },
  { symbol: "HAVELLS.NS", name: "Havells India Ltd", exchange: "NSE", sector: "Electronics" },
  { symbol: "SIEMENS.NS", name: "Siemens Ltd", exchange: "NSE", sector: "Engineering" },
  { symbol: "ABB.NS", name: "ABB India Ltd", exchange: "NSE", sector: "Engineering" },
  { symbol: "TRENT.NS", name: "Trent Ltd", exchange: "NSE", sector: "Retail" },
  { symbol: "MUTHOOTFIN.NS", name: "Muthoot Finance Ltd", exchange: "NSE", sector: "Finance" },
  { symbol: "CHOLAFIN.NS", name: "Cholamandalam Investment and Finance Co Ltd", exchange: "NSE", sector: "Finance" },
  { symbol: "BANKBARODA.NS", name: "Bank of Baroda", exchange: "NSE", sector: "Banking" },
  { symbol: "PNB.NS", name: "Punjab National Bank", exchange: "NSE", sector: "Banking" },
  { symbol: "CANBK.NS", name: "Canara Bank", exchange: "NSE", sector: "Banking" },
  { symbol: "UNIONBANK.NS", name: "Union Bank of India", exchange: "NSE", sector: "Banking" },
  { symbol: "IOC.NS", name: "Indian Oil Corporation Ltd", exchange: "NSE", sector: "Energy" },
  { symbol: "GAIL.NS", name: "GAIL India Ltd", exchange: "NSE", sector: "Energy" },
  { symbol: "SAIL.NS", name: "Steel Authority of India Ltd", exchange: "NSE", sector: "Metals" },
  { symbol: "NMDC.NS", name: "NMDC Ltd", exchange: "NSE", sector: "Mining" },
  { symbol: "HAL.NS", name: "Hindustan Aeronautics Ltd", exchange: "NSE", sector: "Defence" },
  { symbol: "BEL.NS", name: "Bharat Electronics Ltd", exchange: "NSE", sector: "Defence" },
  { symbol: "IRCTC.NS", name: "Indian Railway Catering and Tourism Corporation Ltd", exchange: "NSE", sector: "Travel" },
  { symbol: "TATAPOWER.NS", name: "Tata Power Company Ltd", exchange: "NSE", sector: "Utilities" },
  { symbol: "INDIGO.NS", name: "InterGlobe Aviation Ltd (IndiGo)", exchange: "NSE", sector: "Aviation" },
  { symbol: "LTIM.NS", name: "LTIMindtree Ltd", exchange: "NSE", sector: "Technology" },
  { symbol: "PERSISTENT.NS", name: "Persistent Systems Ltd", exchange: "NSE", sector: "Technology" },
  { symbol: "COFORGE.NS", name: "Coforge Ltd", exchange: "NSE", sector: "Technology" },
  { symbol: "MPHASIS.NS", name: "Mphasis Ltd", exchange: "NSE", sector: "Technology" },
  { symbol: "LICI.NS", name: "Life Insurance Corporation of India", exchange: "NSE", sector: "Insurance" },
  { symbol: "DLF.NS", name: "DLF Ltd", exchange: "NSE", sector: "Real Estate" },
  { symbol: "GODREJPROP.NS", name: "Godrej Properties Ltd", exchange: "NSE", sector: "Real Estate" },
  { symbol: "OBEROIRLTY.NS", name: "Oberoi Realty Ltd", exchange: "NSE", sector: "Real Estate" },
  { symbol: "PRESTIGE.NS", name: "Prestige Estates Projects Ltd", exchange: "NSE", sector: "Real Estate" },
  { symbol: "BHARATFORG.NS", name: "Bharat Forge Ltd", exchange: "NSE", sector: "Engineering" },
  { symbol: "CUMMINSIND.NS", name: "Cummins India Ltd", exchange: "NSE", sector: "Engineering" },
  { symbol: "VOLTAS.NS", name: "Voltas Ltd", exchange: "NSE", sector: "Electronics" },
  { symbol: "WHIRLPOOL.NS", name: "Whirlpool of India Ltd", exchange: "NSE", sector: "Electronics" },
  { symbol: "CROMPTON.NS", name: "Crompton Greaves Consumer Electricals Ltd", exchange: "NSE", sector: "Electronics" },
  { symbol: "BIOCON.NS", name: "Biocon Ltd", exchange: "NSE", sector: "Healthcare" },
  { symbol: "TORNTPHARM.NS", name: "Torrent Pharmaceuticals Ltd", exchange: "NSE", sector: "Healthcare" },
  { symbol: "LUPIN.NS", name: "Lupin Ltd", exchange: "NSE", sector: "Healthcare" },
  { symbol: "AUROPHARMA.NS", name: "Aurobindo Pharma Ltd", exchange: "NSE", sector: "Healthcare" },
  { symbol: "MAXHEALTH.NS", name: "Max Healthcare Institute Ltd", exchange: "NSE", sector: "Healthcare" },
];

export async function seedIndianCompanies(): Promise<number> {
  console.log("Seeding Indian stock exchange companies...");
  let inserted = 0;

  for (const company of INDIAN_STOCKS) {
    try {
      const existing = await db
        .select()
        .from(companies)
        .where(eq(companies.symbol, company.symbol))
        .limit(1);

      if (existing.length === 0) {
        await db.insert(companies).values({
          id: randomUUID(),
          symbol: company.symbol,
          name: company.name,
          exchange: company.exchange,
          sector: company.sector,
        });
        inserted++;
      }
    } catch (error) {
      console.error(`Error inserting company ${company.symbol}:`, error);
    }
  }

  console.log(`Seeded ${inserted} Indian companies`);
  return inserted;
}

export async function fetchCompanyProfile(symbol: string): Promise<FinnhubCompanyProfile | null> {
  try {
    const cleanSymbol = symbol.replace(".NS", "").replace(".BO", "");
    const url = `https://finnhub.io/api/v1/stock/profile2?symbol=${cleanSymbol}&token=${FINNHUB_API_KEY}`;
    const response = await fetch(url);
    
    if (!response.ok) return null;
    
    const data = await response.json();
    return data.name ? data : null;
  } catch (error) {
    console.error(`Error fetching profile for ${symbol}:`, error);
    return null;
  }
}

export async function fetchCompanyNews(symbol: string): Promise<number> {
  try {
    const cleanSymbol = symbol.replace(".NS", "").replace(".BO", "");
    const today = new Date();
    const weekAgo = new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000);
    
    const fromDate = weekAgo.toISOString().split("T")[0];
    const toDate = today.toISOString().split("T")[0];
    
    const url = `https://finnhub.io/api/v1/company-news?symbol=${cleanSymbol}&from=${fromDate}&to=${toDate}&token=${FINNHUB_API_KEY}`;
    const response = await fetch(url);
    
    if (!response.ok) return 0;
    
    const news: FinnhubCompanyNews[] = await response.json();
    let inserted = 0;
    
    for (const item of news.slice(0, 10)) {
      try {
        const existing = await db
          .select()
          .from(newsArticles)
          .where(eq(newsArticles.sourceUrl, item.url))
          .limit(1);

        if (existing.length > 0) continue;

        await db.insert(newsArticles).values({
          id: randomUUID(),
          headline: item.headline,
          summary: item.summary || item.headline,
          content: item.summary || item.headline,
          source: item.source || "Finnhub",
          author: item.source || "Staff Reporter",
          publishedAt: new Date(item.datetime * 1000),
          category: "stocks",
          ticker: symbol,
          imageUrl: item.image || null,
          sourceUrl: item.url,
        });
        inserted++;
      } catch (insertError) {
        // Skip duplicates silently
      }
    }
    
    return inserted;
  } catch (error) {
    console.error(`Error fetching news for ${symbol}:`, error);
    return 0;
  }
}

export async function searchCompanies(query: string) {
  if (!query || query.length < 2) return [];
  
  const results = await db
    .select()
    .from(companies)
    .where(
      or(
        ilike(companies.name, `%${query}%`),
        ilike(companies.symbol, `%${query}%`),
        ilike(companies.sector, `%${query}%`)
      )
    )
    .limit(10);
  
  return results;
}

export async function getCompanyBySymbol(symbol: string) {
  const result = await db
    .select()
    .from(companies)
    .where(eq(companies.symbol, symbol))
    .limit(1);
  
  return result[0] || null;
}

export async function getCompanyNews(symbol: string) {
  const news = await db
    .select()
    .from(newsArticles)
    .where(eq(newsArticles.ticker, symbol))
    .orderBy(desc(newsArticles.publishedAt))
    .limit(20);
  
  return news;
}

export async function getAllCompanies() {
  return await db.select().from(companies).orderBy(companies.name);
}
