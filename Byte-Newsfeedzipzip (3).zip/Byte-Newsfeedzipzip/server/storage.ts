import {
  users,
  newsArticles,
  financialEvents,
  userPreferences,
  savedArticles,
  readingHistory,
  type User,
  type UpsertUser,
  type NewsArticle,
  type InsertNewsArticle,
  type FinancialEvent,
  type InsertFinancialEvent,
  type UserPreferences,
  type InsertUserPreferences,
  type SavedArticle,
  type InsertSavedArticle,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, asc, ilike, or, and, gte, lte, inArray } from "drizzle-orm";

export interface IStorage {
  // User operations (required for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;

  // News articles
  getArticles(options?: {
    category?: string;
    source?: string;
    search?: string;
    ticker?: string;
    sort?: string;
    limit?: number;
    offset?: number;
  }): Promise<NewsArticle[]>;
  getArticle(id: string): Promise<NewsArticle | undefined>;
  createArticle(article: InsertNewsArticle): Promise<NewsArticle>;
  getArticleCount(options?: { category?: string; source?: string }): Promise<number>;

  // Financial events
  getEvents(options?: {
    startDate?: Date;
    endDate?: Date;
    type?: string;
  }): Promise<FinancialEvent[]>;
  createEvent(event: InsertFinancialEvent): Promise<FinancialEvent>;

  // User preferences
  getUserPreferences(userId: string): Promise<UserPreferences | undefined>;
  upsertUserPreferences(prefs: InsertUserPreferences): Promise<UserPreferences>;

  // Saved articles
  getSavedArticles(userId: string): Promise<SavedArticle[]>;
  saveArticle(saved: InsertSavedArticle): Promise<SavedArticle>;
  unsaveArticle(userId: string, articleId: string): Promise<void>;
  isArticleSaved(userId: string, articleId: string): Promise<boolean>;

  // Reading history
  recordArticleRead(userId: string, articleId: string): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // News articles
  async getArticles(options?: {
    category?: string;
    source?: string;
    search?: string;
    ticker?: string;
    sort?: string;
    limit?: number;
    offset?: number;
  }): Promise<NewsArticle[]> {
    const conditions = [];

    if (options?.category && options.category !== "all") {
      conditions.push(eq(newsArticles.category, options.category));
    }

    if (options?.source && options.source !== "all") {
      conditions.push(eq(newsArticles.source, options.source));
    }

    if (options?.ticker) {
      conditions.push(eq(newsArticles.ticker, options.ticker));
    }

    if (options?.search) {
      const searchTerm = `%${options.search}%`;
      conditions.push(
        or(
          ilike(newsArticles.headline, searchTerm),
          ilike(newsArticles.summary, searchTerm),
          ilike(newsArticles.content, searchTerm),
          ilike(newsArticles.ticker, searchTerm)
        )
      );
    }

    let query = db.select().from(newsArticles);

    if (conditions.length > 0) {
      query = query.where(and(...conditions)) as any;
    }

    const sortOrder = options?.sort === "date-asc" ? asc(newsArticles.publishedAt) : desc(newsArticles.publishedAt);
    query = query.orderBy(sortOrder) as any;

    if (options?.limit) {
      query = query.limit(options.limit) as any;
    }

    if (options?.offset) {
      query = query.offset(options.offset) as any;
    }

    return await query;
  }

  async getArticle(id: string): Promise<NewsArticle | undefined> {
    const [article] = await db.select().from(newsArticles).where(eq(newsArticles.id, id));
    return article;
  }

  async createArticle(article: InsertNewsArticle): Promise<NewsArticle> {
    const [created] = await db.insert(newsArticles).values(article).returning();
    return created;
  }

  async getArticleCount(options?: { category?: string; source?: string }): Promise<number> {
    const conditions = [];

    if (options?.category && options.category !== "all") {
      conditions.push(eq(newsArticles.category, options.category));
    }

    if (options?.source && options.source !== "all") {
      conditions.push(eq(newsArticles.source, options.source));
    }

    let query = db.select().from(newsArticles);
    if (conditions.length > 0) {
      query = query.where(and(...conditions)) as any;
    }

    const results = await query;
    return results.length;
  }

  // Financial events
  async getEvents(options?: {
    startDate?: Date;
    endDate?: Date;
    type?: string;
  }): Promise<FinancialEvent[]> {
    const conditions = [];

    if (options?.startDate) {
      conditions.push(gte(financialEvents.date, options.startDate));
    }

    if (options?.endDate) {
      conditions.push(lte(financialEvents.date, options.endDate));
    }

    if (options?.type) {
      conditions.push(eq(financialEvents.type, options.type));
    }

    let query = db.select().from(financialEvents).orderBy(asc(financialEvents.date));

    if (conditions.length > 0) {
      query = query.where(and(...conditions)) as any;
    }

    return await query;
  }

  async createEvent(event: InsertFinancialEvent): Promise<FinancialEvent> {
    const [created] = await db.insert(financialEvents).values(event).returning();
    return created;
  }

  // User preferences
  async getUserPreferences(userId: string): Promise<UserPreferences | undefined> {
    const [prefs] = await db.select().from(userPreferences).where(eq(userPreferences.userId, userId));
    return prefs;
  }

  async upsertUserPreferences(prefs: InsertUserPreferences): Promise<UserPreferences> {
    const [result] = await db
      .insert(userPreferences)
      .values(prefs)
      .onConflictDoUpdate({
        target: userPreferences.userId,
        set: {
          preferredCategories: prefs.preferredCategories,
          preferredSources: prefs.preferredSources,
          updatedAt: new Date(),
        },
      })
      .returning();
    return result;
  }

  // Saved articles
  async getSavedArticles(userId: string): Promise<SavedArticle[]> {
    return await db.select().from(savedArticles).where(eq(savedArticles.userId, userId)).orderBy(desc(savedArticles.savedAt));
  }

  async saveArticle(saved: InsertSavedArticle): Promise<SavedArticle> {
    const [result] = await db.insert(savedArticles).values(saved).returning();
    return result;
  }

  async unsaveArticle(userId: string, articleId: string): Promise<void> {
    await db.delete(savedArticles).where(
      and(eq(savedArticles.userId, userId), eq(savedArticles.articleId, articleId))
    );
  }

  async isArticleSaved(userId: string, articleId: string): Promise<boolean> {
    const [saved] = await db.select().from(savedArticles).where(
      and(eq(savedArticles.userId, userId), eq(savedArticles.articleId, articleId))
    );
    return !!saved;
  }

  // Reading history
  async recordArticleRead(userId: string, articleId: string): Promise<void> {
    await db.insert(readingHistory).values({ userId, articleId });
  }
}

export const storage = new DatabaseStorage();
