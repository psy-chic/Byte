# Byte - Financial News Aggregation Design Guidelines

## Design Approach

**Reference-Based System**: Drawing from Bloomberg Terminal's professional data density and Financial Times' editorial clarity, combined with modern web design principles for optimal financial news consumption.

## Core Design Principles

1. **Information Hierarchy**: Dense but scannable layouts prioritizing headline → source → timestamp → content flow
2. **Professional Authority**: Formal, business-focused aesthetic without playful elements
3. **Data Clarity**: Clear visual separation between news categories, dates, and interactive elements
4. **Responsive Density**: Maintain information richness across all screen sizes

## Typography

**Font Stack**:
- Headlines/Section Titles: Merriweather, serif - weights 700 (primary), 400 (subheadings)
- Body Text/UI: Poppins, sans-serif - weights 600 (bold), 500 (medium), 400 (regular)

**Type Scale**:
- Hero/Page Titles: text-4xl md:text-5xl (Merriweather)
- Section Headers: text-2xl md:text-3xl (Merriweather)
- News Headlines: text-lg md:text-xl (Poppins 600)
- Article Body: text-base (Poppins 400)
- Metadata (source, date): text-sm (Poppins 500)
- UI Labels: text-xs uppercase tracking-wider (Poppins 600)

## Layout System

**Spacing Primitives**: Use Tailwind units of 2, 4, 6, 8, 12, 16, 20 for consistent rhythm
- Component padding: p-4, p-6, p-8
- Section spacing: space-y-8, space-y-12
- Card gaps: gap-4, gap-6
- Container margins: mx-4 md:mx-8 lg:mx-auto

**Grid Structure**:
- Main Container: max-w-7xl mx-auto
- News Feed: 3-column grid on desktop (grid-cols-1 md:grid-cols-2 lg:grid-cols-3)
- Featured Articles: 2-column split for hero content
- Calendar Grid: 7-column for days of week
- Sidebar Filters: Fixed 280px width on desktop, collapsible on mobile

## Component Library

### Navigation
- **Top Bar**: Sticky header with logo (Byte with red "b" and dot), search bar, authentication status, theme toggle
- **Secondary Nav**: Horizontal filter pills for market categories (NSE, Global, Finance)
- **Sidebar**: Persistent left panel (desktop) with saved searches, preferences, trending topics

### News Cards
- **Compact Card** (feed view): 
  - Headline (Poppins 600, 2 lines max with ellipsis)
  - Source logo/name + timestamp on same line
  - Category badge (top-right corner)
  - Hover state: subtle elevation with shadow-md
  
- **Expanded Card** (clicked state):
  - Full headline
  - Author byline
  - Publication date/time
  - Article preview (3-4 lines)
  - "Read Full Article" link
  - TradingView chart embed (for stock news)
  - Source attribution with external link icon

### Interactive Calendar
- **Month View**: Grid layout with date cells
- **Event Indicators**: Small colored dots below dates with news
- **Hover State**: Tooltip showing event count
- **Selected Date**: Highlighted with primary color border, displays news list in side panel

### Search Interface
- **Search Bar**: Prominent placement in header with search icon and clear button
- **Autocomplete**: Dropdown suggestions for companies, topics, dates
- **Results View**: List format with relevance scores and highlighting of search terms

### Authentication
- **Login/Signup Modal**: Clean form with email/password fields, social login options via Replit Auth
- **User Profile**: Dropdown menu in header with preferences, saved articles, logout

### Filters & Sorting
- **Filter Panel**: Multi-select checkboxes for sources, categories, date ranges
- **Sort Options**: Dropdown with Relevance, Date (newest/oldest), Source options
- **Active Filters**: Dismissible chips showing current selections

## Data Visualization

- **Stock Charts**: Embedded TradingView widgets with matching theme colors
- **Trend Indicators**: Small sparkline charts for market movements
- **Statistics Display**: Bold numbers with context labels (e.g., "234 Articles Today")

## Interactions & States

- **Loading States**: Skeleton screens matching card layouts (avoid spinners)
- **Empty States**: Centered messaging with actionable suggestions
- **Error States**: Inline alerts with retry options
- **Hover Effects**: Subtle scale (scale-[1.02]) and shadow transitions
- **Click Feedback**: Brief opacity change (active:opacity-90)

## Images

**Hero Section**: 
- Abstract financial imagery: trading floor, stock market screens, or global economy visualization
- Dark overlay (bg-black/40) for text readability
- Buttons on hero use backdrop-blur-md with bg-white/10

**Article Thumbnails**: 
- Source logos displayed at 40x40px
- Fallback to first letter of source name in colored circle
- Stock-related articles show company logos when available

## Accessibility

- Minimum contrast ratio 4.5:1 for body text, 3:1 for large text
- Focus indicators: 2px ring with primary color
- ARIA labels for interactive elements and dynamic content
- Keyboard navigation through cards and filters
- Screen reader announcements for article count updates

## Responsive Breakpoints

- Mobile (< 768px): Single column, collapsible filters
- Tablet (768px - 1024px): 2-column grid, slide-out sidebar
- Desktop (> 1024px): 3-column grid, persistent sidebar